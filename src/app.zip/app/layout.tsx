import type { Metadata } from "next";
import "./globals.css";

import { AuthProvider } from "@/contexts/AuthContext";
import { CartProvider } from "@/hooks/useCart";
import { NotificationProvider } from "@/components/NotificationProvider";
import OfflineBanner from "@/components/OfflineBanner";
import DatabaseProvider from "@/components/DatabaseProvider";

export const metadata: Metadata = {
  title: "AgriMarché - Votre marché agricole",
  description: "Achetez et vendez des produits agricoles frais au Sénégal",
  manifest: "/manifest.json",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body suppressHydrationWarning>
        <DatabaseProvider>
          <AuthProvider>
            {/* ✅ CartProvider : panier partagé dans toute l'app (header,
                main/products, cart, checkout...) au lieu d'un état isolé
                par page. Doit être sous AuthProvider (useCart dépend de
                useAuth) et au-dessus de tout composant qui appelle useCart(). */}
            <CartProvider>
              <NotificationProvider>
                {children}
                <OfflineBanner />
              </NotificationProvider>
            </CartProvider>
          </AuthProvider>
        </DatabaseProvider>
      </body>
    </html>
  );
}
