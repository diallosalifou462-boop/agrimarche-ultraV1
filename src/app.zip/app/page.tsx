'use client';

import Image from 'next/image';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase/firebase';

export default function SplashPage() {
  const router = useRouter();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // ✅ Progression visuelle rapide (termine avant la redirection)
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 8;
      });
    }, 45);

    // ✅ Redirection selon le rôle après 1200ms (< 2s)
    const timer = setTimeout(() => {
      onAuthStateChanged(auth, async (firebaseUser) => {
        if (!firebaseUser) {
          // Pas connecté → page de login
          router.push('/main/products');
          return;
        }

        // Connecté → vérifier le rôle dans Firestore
        const snap = await getDoc(doc(db, 'users', firebaseUser.uid));
        const role = snap.data()?.role || 'client';

        if (role === 'admin') {
          router.push('/admin');
        } else if (role === 'seller') {
          router.push('/seller/dashboard');
        } else if (role === 'delivery') {
          router.push('/delivery/dashboard');
        } else {
          router.push('/main/products');
        }
      });
    }, 1200);

    return () => {
      clearTimeout(timer);
      clearInterval(progressInterval);
    };
  }, [router]);

  return (
    <div className="relative min-h-screen bg-green-50 flex flex-col items-center justify-center p-6 overflow-hidden">

      {/* LOGO — plus petit, discret */}
      <div className="relative z-10">
        <Image
          src="/logo.png"
          alt="Agrimarché"
          width={120}
          height={120}
          priority
          className="relative z-10"
        />
      </div>

      {/* TITRE */}
      <div className="relative z-10 mt-6 text-center">
        <h1 className="text-3xl font-extrabold tracking-tight text-green-800">
          AgriMarché
        </h1>
      </div>

      {/* PHRASE D'UTILITÉ — dit tout de suite ce que fait l'app */}
      <div className="relative z-10 mt-3">
        <p className="text-green-700 text-center text-base font-medium">
          Achetez et vendez vos récoltes, partout au Sénégal
        </p>
      </div>

      {/* BARRE DE CHARGEMENT — une seule, sans pourcentage ni points */}
      <div className="relative z-10 mt-10 w-56">
        <div className="relative h-1.5 bg-green-200/60 rounded-full overflow-hidden">
          <div
            className="absolute top-0 left-0 h-full bg-green-600 rounded-full transition-all duration-100 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

    </div>
  );
}
